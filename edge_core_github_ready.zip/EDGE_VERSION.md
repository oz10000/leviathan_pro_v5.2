# LEVIATHAN EDGE V5.2
Status: FROZEN
Score Threshold: 68
Logic: DAPS Causal Optimized