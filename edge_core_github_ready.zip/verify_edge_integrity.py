import os
import sys

def check():
    print("--- INICIANDO VALIDACIÓN DEL EDGE CORE ---")
    essential_files = [
        'config.py', 'core/feature_engine.py', 'core/scoring.py',
        'daps/daps_core.py', 'strategies/base_strategy.py',
        'execution/exit_hybrid.py', 'risk/kelly.py'
    ]
    missing = []
    for f in essential_files:
        if not os.path.exists(f):
            missing.append(f)
    
    if missing:
        print(f"ERROR: Faltan archivos críticos: {missing}")
        sys.exit(1)
    
    print("VERIFICACIÓN EXITOSA: El Edge Core es matemáticamente íntegro.")

if __name__ == '__main__':
    check()