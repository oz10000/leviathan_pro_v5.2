import numpy as np
from config import Config

class HybridExit:
    @staticmethod
    def should_exit(pos: dict, current_price: float, current_time: int):
        """
        Lógica matemática de salida Leviathan.
        Basada en ATR dinámico, Break-Even y Time Decay.
        """
        entry = pos['entry']
        atr = pos['atr']
        side = pos['dir']
        lev = pos['leverage']
        
        # Cálculo de PnL no realizado
        pnl_pct = ((current_price - entry) / entry) * side * lev
        
        # 1. STOP LOSS (Congelado en SL_ATR)
        sl_price = entry - (side * atr * Config.SL_ATR)
        if (side == 1 and current_price <= sl_price) or (side == -1 and current_price >= sl_price):
            return True, "STOP_LOSS", sl_price, None
            
        # 2. TAKE PROFIT (Congelado en TP_ATR)
        tp_price = entry + (side * atr * Config.TP_ATR)
        if (side == 1 and current_price >= tp_price) or (side == -1 and current_price <= tp_price):
            return True, "TAKE_PROFIT", tp_price, None

        # 3. BREAK-EVEN LOGIC
        be_threshold = entry + (side * atr * Config.BE_ATR)
        updated_pos = pos.copy()
        if not pos.get('be_active', False):
            if (side == 1 and current_price >= be_threshold) or (side == -1 and current_price <= be_threshold):
                updated_pos['be_active'] = True
                updated_pos['trail_sl'] = entry + (side * atr * 0.1) # Cubre fees
        
        # 4. TRAILING STOP
        if updated_pos.get('be_active', False):
            trail_price = current_price - (side * atr * Config.TRAIL_ATR)
            if side == 1:
                updated_pos['trail_sl'] = max(updated_pos.get('trail_sl', 0), trail_price)
                if current_price <= updated_pos['trail_sl']:
                    return True, "TRAILING_STOP", updated_pos['trail_sl'], None
            else:
                updated_pos['trail_sl'] = min(updated_pos.get('trail_sl', 999999), trail_price)
                if current_price >= updated_pos['trail_sl']:
                    return True, "TRAILING_STOP", updated_pos['trail_sl'], None
        
        return False, None, current_price, updated_pos